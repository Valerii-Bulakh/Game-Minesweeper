/**
 * index
 */

export { GameModule } from './game.module';
