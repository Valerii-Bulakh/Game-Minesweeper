/**
 * index
 */

export { GameTileComponent } from './game-tile.component';
