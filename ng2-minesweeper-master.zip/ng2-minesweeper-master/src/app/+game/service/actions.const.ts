/**
 * actions.enum
 */

export const STORE_TILES = 'STORE_TILES';
export const REVEAL_TILE = 'REVEAL_TILE';
export const COVER_TILE = 'COVER_TILE';
export const UNCOVER_TILE = 'UNCOVER_TILE';
export const HIT_MINE = 'HIT_MINE';
export const REVEAL_ALL = 'REVEAL_ALL';