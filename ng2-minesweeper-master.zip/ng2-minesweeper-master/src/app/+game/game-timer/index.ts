/**
 * index
 */

export { GameTimerComponent } from './game-timer.component';
