/**
 * index
 */

export { GameBoardComponent } from './game-board.component';
