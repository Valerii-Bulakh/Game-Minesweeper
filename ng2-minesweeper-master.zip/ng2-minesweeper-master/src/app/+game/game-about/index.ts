/**
 * index
 */

export { GameAboutComponent } from './about.component';
export { SocialBtnComponent } from './social-btn.component';
